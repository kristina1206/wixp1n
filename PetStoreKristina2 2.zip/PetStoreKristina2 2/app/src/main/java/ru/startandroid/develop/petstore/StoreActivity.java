package ru.startandroid.develop.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class StoreActivity extends AppCompatActivity
{
    private Switch aSwitch;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);

        aSwitch = findViewById(R.id.switchOrder);
        button = findViewById(R.id.buttonOrderPost);
        button.setClickable(false);

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (isChecked)
                {
                    button.setClickable(true);
                }
                else
                {
                    button.setClickable(false);
                }
            }
        });
    }

    public void orderPost(View v)
    {
        EditText etid = findViewById(R.id.postOrderETID);
        EditText etpetid = findViewById(R.id.postOrderETPetID);
        EditText etquantity = findViewById(R.id.postOrderETQuantity);
        EditText etshipdate = findViewById(R.id.postOrderETShipDate);
        EditText etstatus = findViewById(R.id.postOrderETStatus);

        TextView errorTV = findViewById(R.id.orderErrorTV);

        int id = Integer.parseInt(String.valueOf(etid.getText()));
        int petid = Integer.parseInt(String.valueOf(etpetid.getText()));
        int quantity = Integer.parseInt(String.valueOf(etquantity.getText()));
        String shipdate = String.valueOf(etshipdate.getText());
        String status = String.valueOf(etstatus.getText());
        Boolean confirmation = true;

        Order order = new Order();

        order.setId(id);
        order.setPetId(petid);
        order.setQuantity(quantity);
        order.setShipDate(shipdate);
        order.setStatus(status);
        order.setComplete(confirmation);

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://petstore.swagger.io/v2/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

        Call<Void> call = jsonPlaceHolderApi.postOrder(order);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response)
            {
                if (!response.isSuccessful())
                {
                    errorTV.setText(String.valueOf(response.code()));
                    return;
                }

            }

            @Override
            public void onFailure(Call<Void> call, Throwable t)
            {
                errorTV.setText("errror" + t.getMessage());
            }
        });
    }

    public void goMenu(View v)
    {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
        finish();
    }

    public void goOrderSearch(View v)
    {
        Intent intent = new Intent(this, OrderSearch.class);
        startActivity(intent);
        finish();
    }


}