package ru.startandroid.develop.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void goPet(View v)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    public void goStore(View v)
    {
        Intent intent = new Intent(this, StoreActivity.class);
        startActivity(intent);
        finish();
    }
    /*public void goUser(View v)
    {
        Intent intent = new Intent(this, UserActivity.class);
        startActivity(intent);
        finish();
    }*/
}